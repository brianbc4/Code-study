package com.wuxiaolong.androidmvpsample.mvp.main;

/**
 * Created by Administrator
 * on 2016/10/19.
 */

public interface BaseView {
    void showLoading();

    void hideLoading();
}
