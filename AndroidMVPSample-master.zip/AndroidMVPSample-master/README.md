> MVP+Retrofit+RxJava实践小结，此Sample最初是Android MVP示例，后来融合Retrofit和RxJava，供参考。


# 效果预览
![](http://7q5c2h.com1.z0.glb.clouddn.com/mvp_retrofit_rxjava.jpg)

# 详见博客
[Android MVP+Retrofit+RxJava实践小结](http://wuxiaolong.me/2016/06/12/mvpRetrofitRxjava/)

# 推荐阅读
1. [Android MVP 实例](http://wuxiaolong.me/2015/09/23/AndroidMVPSample/)

1. [Android Retrofit 2.0 使用-补充篇](http://wuxiaolong.me/2016/06/18/retrofits/)

1. [Android Retrofit 2.0使用](http://wuxiaolong.me/2016/01/15/retrofit/)

1. [RxJava](http://wuxiaolong.me/2016/01/18/rxjava/)

1. [RxBus](http://wuxiaolong.me/2016/04/07/rxbus/)

# 联系我
我的微信公众号：吴小龙同学，欢迎关注交流。

![](http://7q5c2h.com1.z0.glb.clouddn.com/qrcode_wuxiaolong.jpg)


# 更多交流
Android技术交流群-剩者为王④群：331553260

![](http://7q5c2h.com1.z0.glb.clouddn.com/qun4.png)



# 关于作者
[点击查看](http://wuxiaolong.me/about/)
